<?php

require_once "..\BD\conexaoBD.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        
	$campo2  = $_POST['campo2'] ?? '';
	$campo3   = $_POST['campo3'] ?? '';
	$campo4  = $_POST['campo4'] ?? '';
	$campo5 = $_POST['campo5'] ?? '';
	try{
		$sql = "INSERT INTO usuarios (nome, email, senha, data_cadastro) VALUES (:nome, :email, :senha, :data_cadastro)";
		$stmt = $conexao->prepare($sql);
		$stmt->execute([
			':nome'  => $campo2,
			':email'   => $campo3,
			':senha'  => $campo4,
			':data_cadastro' => $campo5
		]);

		echo "<p>Registro cadastrado com sucesso!</p>";
	} catch (PDOException $e) {
    echo "Erro ao cadastrar: " . $e->getMessage();
	}
}

else {
	echo "<p>Requisição inválida.</p>";
} 	

?>

