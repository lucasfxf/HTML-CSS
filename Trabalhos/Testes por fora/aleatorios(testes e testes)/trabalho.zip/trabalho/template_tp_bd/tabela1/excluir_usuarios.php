<?php 
	require_once "..\BD\conexaoBD.php";
	if (isset($_GET['id_usuarios'])) {
		$id = $_GET['id_usuarios'];

		$stmt = $conexao->prepare("DELETE FROM usuarios WHERE id_usuarios = :id_usuarios");
		$stmt->bindParam(':id', $id, PDO::PARAM_INT);

		if ($stmt->execute()) {
			header("Location: consulta_usuarios.php"); 
			exit;
		} else {
			echo "Erro ao excluir o registro.";
		}
	} else {
		echo "ID não fornecido.";
	}
?>

